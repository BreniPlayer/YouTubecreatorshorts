
from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        return redirect('/resultados')
    return render_template('upload.html', canal='Seu Canal')

@app.route('/resultados')
def resultados():
    shorts = [
        ('shorts/exemplo1.mp4', 'Exemplo 1', '#exemplo #shorts'),
        ('shorts/exemplo2.mp4', 'Exemplo 2', '#video #curto')
    ]
    return render_template('resultados.html', shorts=shorts)

if __name__ == '__main__':
    app.run(debug=True)
