VidTYAI - Pacote completo front-end (estático)

Conteudo do pacote (estrutura):
- index.html
- css/style.css
- js/app.js
- assets/images/preview.png
- assets/video/vid_promo.mp4 (adicione seu video promocional aqui)
- admin/painel.html

O que está incluído:
- Design escuro profissional com paleta azul/ciano.
- Seções: hero, como funciona, upload, planos, preços, FAQ e admin mockup.
- Simulação de upload/processamento no frontend (arquivo estático).
- Instrucoes para integrar backend, pagamentos e analytics.

Lista numerada dos campos que voce pode substituir rapidamente:
1) Nome da marca (logo textual) - index.html div.logo-text
2) Titulo da aba - head > title
3) Slogan principal - hero h1
4) Texto descritivo - meta description e section #sobre
5) Links de redes sociais - footer
6) Imagem de preview - assets/images/preview.png
7) Video promocional - assets/video/vid_promo.mp4
8) Integração com backend - js/app.js BACKEND_UPLOAD_URL
9) Integração de pagamentos - ver README (Stripe/MercadoPago)
10) Analytics/Search Console - head do index.html

Deploy rapido:
- Netlify: drag-and-drop da pasta -> publica instantaneamente.
- Vercel: conectar repo GitHub -> deploy automatico.
- GitHub Pages: subir repo e ativar GitHub Pages.

Como avancar para processamento real:
- Criar backend (FastAPI/Express) com ffmpeg
- Endpoint POST /upload para receber multipart/form-data
- Processar com scripts (ffmpeg) e devolver links

Se quiser, eu crio o backend pronto para Render/Railway.
